import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Base user table (kept from original schema)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Course level enum type
export const CourseLevelEnum = z.enum(["foundation", "diploma", "degree"]);
export type CourseLevel = z.infer<typeof CourseLevelEnum>;

// Notes table
export const notes = pgTable("notes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  content: text("content").notNull(),
  level: text("level").notNull(), // foundation, diploma, degree
  course: text("course").notNull(),
  topic: text("topic").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertNoteSchema = createInsertSchema(notes).omit({
  id: true,
  createdAt: true,
});

export type InsertNote = z.infer<typeof insertNoteSchema>;
export type Note = typeof notes.$inferSelect;

// Previous Year Questions (PYQs) table
export const pyqs = pgTable("pyqs", {
  id: serial("id").primaryKey(),
  subject: text("subject").notNull(),
  level: text("level").notNull(), // foundation, diploma, degree
  year: integer("year").notNull(),
  term: text("term").notNull(), // Jan-May, Aug-Dec
  examType: text("exam_type").notNull(), // End Term, Mid Term, Quiz
  fileUrl: text("file_url").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertPYQSchema = createInsertSchema(pyqs).omit({
  id: true,
  createdAt: true,
});

export type InsertPYQ = z.infer<typeof insertPYQSchema>;
export type PYQ = typeof pyqs.$inferSelect;

// Code Notes table
export const codeNotes = pgTable("code_notes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  code: text("code").notNull(),
  language: text("language").notNull(),
  tags: text("tags").array().notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertCodeNoteSchema = createInsertSchema(codeNotes).omit({
  id: true,
  createdAt: true,
});

export type InsertCodeNote = z.infer<typeof insertCodeNoteSchema>;
export type CodeNote = typeof codeNotes.$inferSelect;

// Resources (for Home page quick links)
export const resources = pgTable("resources", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  icon: text("icon").notNull(),
  link: text("link").notNull(),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertResourceSchema = createInsertSchema(resources).omit({
  id: true,
  createdAt: true,
});

export type InsertResource = z.infer<typeof insertResourceSchema>;
export type Resource = typeof resources.$inferSelect;

// GPA Calculation schemas (these won't be stored in DB)
export const courseGradeSchema = z.object({
  code: z.string().min(1, "Course code is required"),
  credits: z.number().min(1, "Credits must be at least 1"),
  grade: z.string().min(1, "Grade is required")
});

export const semesterSchema = z.object({
  gpa: z.number().min(0, "GPA must be at least 0").max(10, "GPA cannot exceed 10"),
  credits: z.number().min(1, "Credits must be at least 1")
});

export type CourseGrade = z.infer<typeof courseGradeSchema>;
export type SemesterGrade = z.infer<typeof semesterSchema>;
