import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import Layout from "@/components/Layout";
import Home from "@/pages/Home";
import Notes from "@/pages/Notes";
import PreviousYearQuestions from "@/pages/PreviousYearQuestions";
import CodeNotes from "@/pages/CodeNotes";
import GPACalculator from "@/pages/GPACalculator";
import NoteDetails from "@/pages/NoteDetails";
import CodeNoteDetails from "@/pages/CodeNoteDetails";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/notes" component={Notes} />
        <Route path="/notes/:id" component={NoteDetails} />
        <Route path="/pyqs" component={PreviousYearQuestions} />
        <Route path="/code-notes" component={CodeNotes} />
        <Route path="/code-notes/:id" component={CodeNoteDetails} />
        <Route path="/gpa-calculator" component={GPACalculator} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router />
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
