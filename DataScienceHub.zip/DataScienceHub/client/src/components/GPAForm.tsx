import { useState } from "react";
import { Plus } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

interface Course {
  code: string;
  credits: number;
  grade: string;
}

const GPAForm = () => {
  const { toast } = useToast();
  const [courses, setCourses] = useState<Course[]>([{ code: "", credits: 3, grade: "" }]);
  const [gpa, setGPA] = useState<string>("0.00");
  const [isCalculating, setIsCalculating] = useState(false);

  const handleAddCourse = () => {
    setCourses([...courses, { code: "", credits: 3, grade: "" }]);
  };

  const handleRemoveCourse = (index: number) => {
    if (courses.length > 1) {
      setCourses(courses.filter((_, i) => i !== index));
    }
  };

  const handleCourseChange = (index: number, field: keyof Course, value: string | number) => {
    const updatedCourses = [...courses];
    updatedCourses[index] = { ...updatedCourses[index], [field]: value };
    setCourses(updatedCourses);
  };

  const handleCalculateGPA = async () => {
    try {
      setIsCalculating(true);
      // Validate input
      for (const course of courses) {
        if (!course.code.trim()) {
          toast({
            title: "Validation Error",
            description: "Please enter a course code for all courses",
            variant: "destructive",
          });
          setIsCalculating(false);
          return;
        }
        if (!course.grade) {
          toast({
            title: "Validation Error",
            description: "Please select a grade for all courses",
            variant: "destructive",
          });
          setIsCalculating(false);
          return;
        }
      }

      const response = await apiRequest("POST", "/api/calculate-gpa", {
        courses: courses.map(course => ({
          ...course,
          credits: Number(course.credits)
        }))
      });
      
      const data = await response.json();
      setGPA(data.gpa);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to calculate GPA. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsCalculating(false);
    }
  };

  return (
    <div className="bg-neutral-50 p-6 rounded-lg border border-neutral-200">
      <div className="mb-4">
        <p className="text-neutral-600 mb-2">Add your courses for this semester:</p>
        <div className="space-y-4">
          <div className="grid grid-cols-12 gap-4 font-medium text-sm text-neutral-500">
            <div className="col-span-5">Course Code</div>
            <div className="col-span-3">Credits</div>
            <div className="col-span-3">Grade</div>
            <div className="col-span-1"></div>
          </div>
          
          {courses.map((course, index) => (
            <div key={index} className="grid grid-cols-12 gap-4 items-center">
              <div className="col-span-5">
                <Input
                  type="text"
                  value={course.code}
                  onChange={(e) => handleCourseChange(index, "code", e.target.value)}
                  placeholder="e.g. MATH101"
                  className="w-full"
                />
              </div>
              <div className="col-span-3">
                <Select
                  value={course.credits.toString()}
                  onValueChange={(value) => handleCourseChange(index, "credits", parseInt(value))}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Credits" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">1</SelectItem>
                    <SelectItem value="2">2</SelectItem>
                    <SelectItem value="3">3</SelectItem>
                    <SelectItem value="4">4</SelectItem>
                    <SelectItem value="5">5</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-3">
                <Select
                  value={course.grade}
                  onValueChange={(value) => handleCourseChange(index, "grade", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select Grade" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">S (10)</SelectItem>
                    <SelectItem value="9">A (9)</SelectItem>
                    <SelectItem value="8">B (8)</SelectItem>
                    <SelectItem value="7">C (7)</SelectItem>
                    <SelectItem value="6">D (6)</SelectItem>
                    <SelectItem value="5">E (5)</SelectItem>
                    <SelectItem value="0">U (0)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-1">
                {courses.length > 1 && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleRemoveCourse(index)}
                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex gap-4">
        <Button 
          variant="outline"
          onClick={handleAddCourse}
          className="text-[#800000] border-[#800000]"
        >
          <Plus className="h-5 w-5 mr-1" />
          Add Course
        </Button>
        <Button 
          onClick={handleCalculateGPA} 
          className="bg-[#800000] hover:bg-[#690000]"
          disabled={isCalculating}
        >
          {isCalculating ? "Calculating..." : "Calculate GPA"}
        </Button>
      </div>

      <Card className="mt-6">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium text-neutral-800">Your GPA</h3>
            <span className="text-3xl font-bold text-[#800000]">{gpa}</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default GPAForm;
