import { useState } from "react";
import { Clipboard, Download, Check } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

interface CodeBlockProps {
  title: string;
  language: string;
  code: string;
  tags: string[];
}

const CodeBlock = ({ title, language, code, tags }: CodeBlockProps) => {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownload = () => {
    const element = document.createElement("a");
    const file = new Blob([code], { type: "text/plain" });
    element.href = URL.createObjectURL(file);
    element.download = `${title.toLowerCase().replace(/\s+/g, "_")}.${
      language === "python" ? "py" : language
    }`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-neutral-50 border-b border-neutral-200 flex flex-row justify-between items-center p-4">
        <CardTitle className="font-sans font-medium text-lg text-neutral-800">{title}</CardTitle>
        <div className="flex space-x-2">
          <button
            onClick={handleCopy}
            className="text-[#14397d] hover:text-[#800000]"
            title="Copy to clipboard"
          >
            {copied ? <Check className="h-5 w-5" /> : <Clipboard className="h-5 w-5" />}
          </button>
          <button
            onClick={handleDownload}
            className="text-[#14397d] hover:text-[#800000]"
            title="Download"
          >
            <Download className="h-5 w-5" />
          </button>
        </div>
      </CardHeader>
      <CardContent className="p-4">
        <pre className="font-mono text-sm bg-neutral-900 text-white p-4 rounded-md overflow-x-auto whitespace-pre-wrap">
          {code}
        </pre>
        <div className="mt-4">
          <h4 className="font-medium text-neutral-800 mb-2">Related Topics:</h4>
          <div className="flex flex-wrap gap-2">
            {tags.map((tag) => (
              <Badge key={tag} variant="secondary" className="bg-[#14397d] bg-opacity-10 text-[#14397d]">
                {tag}
              </Badge>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default CodeBlock;
