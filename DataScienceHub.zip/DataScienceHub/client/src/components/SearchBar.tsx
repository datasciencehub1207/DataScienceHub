import { useState } from "react";
import { useLocation } from "wouter";
import { Search } from "lucide-react";
import { Input } from "@/components/ui/input";

const SearchBar = () => {
  const [query, setQuery] = useState("");
  const [, setLocation] = useLocation();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      // In a real app, we would implement search functionality
      // For now, just navigate to the notes page
      setLocation(`/notes`);
    }
  };

  return (
    <form onSubmit={handleSearch} className="relative w-full max-w-xs lg:max-w-md">
      <Input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        className="rounded-full pr-10"
        placeholder="Search resources..."
      />
      <div className="absolute inset-y-0 right-0 flex items-center pr-3">
        <Search className="h-4 w-4 text-gray-400" />
      </div>
    </form>
  );
};

export default SearchBar;
