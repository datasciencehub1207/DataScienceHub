import { Link } from "wouter";
import { Button } from "@/components/ui/button";

const Hero = () => {
  return (
    <div className="bg-[#800000] relative overflow-hidden">
      <div className="absolute inset-y-0 right-0 hidden w-1/2 overflow-hidden lg:block">
        <img
          className="h-full w-full object-cover opacity-20"
          src="https://images.unsplash.com/photo-1544383835-bda2bc66a55d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1121&q=80"
          alt="Data Science Hub Campus"
        />
      </div>
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="py-16 md:py-20 lg:py-24 max-w-3xl">
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-sans font-bold text-white leading-tight">
            Academic Resources for IIT Madras BS Students
          </h1>
          <p className="mt-4 text-white text-lg md:text-xl opacity-90">
            Access comprehensive notes, previous year questions, code snippets, and a GPA calculator
            to help you excel in your studies.
          </p>
          <div className="mt-8 flex flex-wrap gap-4">
            <Link href="/notes">
              <Button
                className="bg-white text-[#800000] hover:bg-neutral-100 px-5 py-6 font-medium"
                size="lg"
              >
                Browse Resources
              </Button>
            </Link>
            <Link href="/gpa-calculator">
              <Button
                className="bg-[#14397d] hover:bg-[#0c2654] px-5 py-6 font-medium"
                size="lg"
              >
                Calculate GPA
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
