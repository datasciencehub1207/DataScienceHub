import { Link } from "wouter";
import { Facebook, Twitter, Linkedin, Instagram, Mail } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import logoSvg from "../assets/logo.svg";

const Footer = () => {
  return (
    <footer className="bg-[#0c2654] text-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <div className="flex items-center mb-4">
              <img
                className="h-8 w-auto"
                src={logoSvg}
                alt="Data Science Hub Logo"
              />
              <div className="ml-3">
                <p className="font-sans font-bold text-lg leading-tight">Data Science</p>
                <p className="text-xs font-medium leading-tight text-white text-opacity-80">
                  Hub
                </p>
              </div>
            </div>
            <p className="text-sm text-white text-opacity-80 mb-4">
              Academic resources for students enrolled in the IIT Madras BS in Data Science program.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="text-white hover:text-[#f3b617]" aria-label="Twitter">
                <Twitter className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-[#f3b617]" aria-label="Instagram">
                <Instagram className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-[#f3b617]" aria-label="LinkedIn">
                <Linkedin className="h-5 w-5" />
              </a>
              <a href="#" className="text-white hover:text-[#f3b617]" aria-label="Facebook">
                <Facebook className="h-5 w-5" />
              </a>
            </div>
          </div>
          <div>
            <h3 className="text-lg font-sans font-medium mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/">
                  <a className="text-white text-opacity-80 hover:text-white text-sm">Home</a>
                </Link>
              </li>
              <li>
                <Link href="/notes">
                  <a className="text-white text-opacity-80 hover:text-white text-sm">Course Notes</a>
                </Link>
              </li>
              <li>
                <Link href="/pyqs">
                  <a className="text-white text-opacity-80 hover:text-white text-sm">
                    Previous Year Questions
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/code-notes">
                  <a className="text-white text-opacity-80 hover:text-white text-sm">Code Notes</a>
                </Link>
              </li>
              <li>
                <Link href="/gpa-calculator">
                  <a className="text-white text-opacity-80 hover:text-white text-sm">GPA Calculator</a>
                </Link>
              </li>
              <li>
                <a href="#" className="text-white text-opacity-80 hover:text-white text-sm">
                  About Us
                </a>
              </li>
              <li>
                <a href="#" className="text-white text-opacity-80 hover:text-white text-sm">
                  Contact
                </a>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-sans font-medium mb-4">Contact</h3>
            <ul className="space-y-2">
              <li className="flex items-start">
                <Mail className="h-5 w-5 mr-2 text-white text-opacity-80" />
                <span className="text-white text-opacity-80 text-sm">dshubhelp@gmail.com</span>
              </li>
            </ul>
            <div className="mt-6">
              <h3 className="text-lg font-sans font-medium mb-4">Subscribe to Updates</h3>
              <form className="flex">
                <Input
                  type="email"
                  placeholder="Your email"
                  className="rounded-r-none text-neutral-800"
                />
                <Button className="bg-[#f3b617] hover:bg-[#d99f0d] rounded-l-none">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    className="h-5 w-5"
                    viewBox="0 0 20 20"
                    fill="currentColor"
                  >
                    <path
                      fillRule="evenodd"
                      d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z"
                      clipRule="evenodd"
                    />
                  </svg>
                </Button>
              </form>
            </div>
          </div>
        </div>
        <div className="mt-8 pt-8 border-t border-white border-opacity-20 text-center">
          <p className="text-sm text-white text-opacity-60">
            &copy; 2025 Data Science Hub Resources. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
