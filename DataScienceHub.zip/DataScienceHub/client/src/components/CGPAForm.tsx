import { useState } from "react";
import { Plus } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";

interface Semester {
  gpa: string;
  credits: number;
}

const CGPAForm = () => {
  const { toast } = useToast();
  const [semesters, setSemesters] = useState<Semester[]>([{ gpa: "", credits: 15 }]);
  const [cgpa, setCGPA] = useState<string>("0.00");
  const [isCalculating, setIsCalculating] = useState(false);

  const handleAddSemester = () => {
    setSemesters([...semesters, { gpa: "", credits: 15 }]);
  };

  const handleRemoveSemester = (index: number) => {
    if (semesters.length > 1) {
      setSemesters(semesters.filter((_, i) => i !== index));
    }
  };

  const handleSemesterChange = (index: number, field: keyof Semester, value: string | number) => {
    const updatedSemesters = [...semesters];
    updatedSemesters[index] = { ...updatedSemesters[index], [field]: value };
    setSemesters(updatedSemesters);
  };

  const handleCalculateCGPA = async () => {
    try {
      setIsCalculating(true);
      // Validate input
      for (const semester of semesters) {
        if (!semester.gpa.trim()) {
          toast({
            title: "Validation Error",
            description: "Please enter a GPA for all semesters",
            variant: "destructive",
          });
          setIsCalculating(false);
          return;
        }
        const gpaValue = parseFloat(semester.gpa);
        if (isNaN(gpaValue) || gpaValue < 0 || gpaValue > 10) {
          toast({
            title: "Validation Error",
            description: "GPA must be a number between 0 and 10",
            variant: "destructive",
          });
          setIsCalculating(false);
          return;
        }
      }

      const response = await apiRequest("POST", "/api/calculate-cgpa", {
        semesters: semesters.map(semester => ({
          gpa: parseFloat(semester.gpa),
          credits: Number(semester.credits)
        }))
      });
      
      const data = await response.json();
      setCGPA(data.cgpa);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to calculate CGPA. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsCalculating(false);
    }
  };

  return (
    <div className="bg-neutral-50 p-6 rounded-lg border border-neutral-200">
      <div className="mb-4">
        <p className="text-neutral-600 mb-2">Add your semesters:</p>
        <div className="space-y-4">
          <div className="grid grid-cols-12 gap-4 font-medium text-sm text-neutral-500">
            <div className="col-span-6">Semester</div>
            <div className="col-span-3">GPA</div>
            <div className="col-span-2">Credits</div>
            <div className="col-span-1"></div>
          </div>
          
          {semesters.map((semester, index) => (
            <div key={index} className="grid grid-cols-12 gap-4 items-center">
              <div className="col-span-6">
                <span className="font-medium">Semester {index + 1}</span>
              </div>
              <div className="col-span-3">
                <Input
                  type="number"
                  min="0"
                  max="10"
                  step="0.01"
                  value={semester.gpa}
                  onChange={(e) => handleSemesterChange(index, "gpa", e.target.value)}
                  placeholder="GPA (0-10)"
                  className="w-full"
                />
              </div>
              <div className="col-span-2">
                <Input
                  type="number"
                  min="1"
                  value={semester.credits.toString()}
                  onChange={(e) => handleSemesterChange(index, "credits", parseInt(e.target.value) || 0)}
                  placeholder="Credits"
                  className="w-full"
                />
              </div>
              <div className="col-span-1">
                {semesters.length > 1 && (
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => handleRemoveSemester(index)}
                    className="text-red-500 hover:text-red-700 hover:bg-red-50"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-5 w-5"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </Button>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="flex gap-4">
        <Button 
          variant="outline"
          onClick={handleAddSemester}
          className="text-[#800000] border-[#800000]"
        >
          <Plus className="h-5 w-5 mr-1" />
          Add Semester
        </Button>
        <Button 
          onClick={handleCalculateCGPA} 
          className="bg-[#800000] hover:bg-[#690000]"
          disabled={isCalculating}
        >
          {isCalculating ? "Calculating..." : "Calculate CGPA"}
        </Button>
      </div>

      <Card className="mt-6">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-medium text-neutral-800">Your CGPA</h3>
            <span className="text-3xl font-bold text-[#800000]">{cgpa}</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default CGPAForm;
