import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  Sheet,
  SheetClose,
  SheetContent,
  SheetTrigger,
} from "@/components/ui/sheet";
import { Menu } from "lucide-react";
import SearchBar from "./SearchBar";
import logoSvg from "../assets/logo.svg";

const Header = () => {
  const [location] = useLocation();

  const navLinks = [
    { name: "Home", path: "/" },
    { name: "Notes", path: "/notes" },
    { name: "PYQs", path: "/pyqs" },
    { name: "Code Notes", path: "/code-notes" },
    { name: "GPA Calculator", path: "/gpa-calculator" },
  ];

  return (
    <header className="bg-white shadow-sm sticky top-0 z-30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center py-3 md:space-x-10">
          <div className="flex justify-start lg:w-0 lg:flex-1">
            <Link href="/">
              <a className="flex items-center">
                <img
                  className="h-10 w-auto"
                  src={logoSvg}
                  alt="Data Science Hub Logo"
                />
                <div className="ml-3 flex flex-col">
                  <span className="text-[#800000] font-sans font-bold text-lg leading-tight">
                    Data Science
                  </span>
                  <span className="text-[#14397d] text-xs font-medium leading-tight">
                    Hub
                  </span>
                </div>
              </a>
            </Link>
          </div>

          <div className="-mr-2 -my-2 md:hidden">
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="icon">
                  <Menu className="h-5 w-5" />
                  <span className="sr-only">Open menu</span>
                </Button>
              </SheetTrigger>
              <SheetContent side="left">
                <div className="flex-shrink-0 flex items-center px-4 py-4">
                  <img
                    className="h-10 w-auto"
                    src={logoSvg}
                    alt="Data Science Hub Logo"
                  />
                  <div className="ml-3">
                    <p className="text-[#800000] font-sans font-bold text-lg leading-tight">
                      Data Science
                    </p>
                    <p className="text-[#14397d] text-xs font-medium leading-tight">
                      Hub
                    </p>
                  </div>
                </div>
                <nav className="mt-5 px-2 space-y-1">
                  {navLinks.map((link) => (
                    <SheetClose asChild key={link.path}>
                      <Link href={link.path}>
                        <a
                          className={`group flex items-center px-2 py-2 text-base font-medium rounded-md ${
                            location === link.path
                              ? "bg-[#800000] text-white"
                              : "text-neutral-800 hover:bg-neutral-100"
                          }`}
                        >
                          {link.name}
                        </a>
                      </Link>
                    </SheetClose>
                  ))}
                </nav>
                <div className="mt-4 px-4">
                  <SearchBar />
                </div>
              </SheetContent>
            </Sheet>
          </div>

          <nav className="hidden md:flex space-x-6">
            {navLinks.map((link) => (
              <Link href={link.path} key={link.path}>
                <a
                  className={`${
                    location === link.path
                      ? "text-[#800000]"
                      : "text-[#14397d] hover:text-[#800000]"
                  } font-medium`}
                >
                  {link.name}
                </a>
              </Link>
            ))}
          </nav>

          <div className="hidden md:flex items-center justify-end md:flex-1 lg:w-0">
            <SearchBar />
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
