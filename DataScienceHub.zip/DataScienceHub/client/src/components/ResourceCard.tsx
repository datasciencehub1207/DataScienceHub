import { Link } from "wouter";
import { FileText, HelpCircle, Code, Calculator } from "lucide-react";

interface ResourceCardProps {
  title: string;
  description: string;
  icon: string;
  link: string;
}

const ResourceCard = ({ title, description, icon, link }: ResourceCardProps) => {
  const getIcon = () => {
    switch (icon) {
      case "FileText":
        return <FileText className="h-8 w-8 text-[#800000]" />;
      case "HelpCircle":
        return <HelpCircle className="h-8 w-8 text-[#14397d]" />;
      case "Code":
        return <Code className="h-8 w-8 text-[#d99f0d]" />;
      case "Calculator":
        return <Calculator className="h-8 w-8 text-[#800000]" />;
      default:
        return <FileText className="h-8 w-8 text-[#800000]" />;
    }
  };

  return (
    <Link href={link}>
      <a className="flex flex-col items-center p-6 bg-neutral-50 border border-neutral-200 rounded-lg hover:shadow-md transition-shadow duration-200">
        <div className="w-16 h-16 flex items-center justify-center bg-opacity-10 rounded-full mb-4 bg-[#a02020]">
          {getIcon()}
        </div>
        <h3 className="text-lg font-sans font-medium text-neutral-800 mb-2">{title}</h3>
        <p className="text-sm text-neutral-600 text-center">{description}</p>
      </a>
    </Link>
  );
};

export default ResourceCard;
