import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { CheckCircle } from "lucide-react";
import { Link } from "wouter";
import { Note } from "@shared/schema";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

const NoteTabs = () => {
  const [activeTab, setActiveTab] = useState("foundation");

  const { data: notes, isLoading } = useQuery<Note[]>({
    queryKey: ["/api/notes"],
  });

  const filterNotesByLevel = (level: string) => {
    return notes?.filter((note) => note.level === level) || [];
  };

  const groupNotesByCourse = (filteredNotes: Note[]) => {
    return filteredNotes.reduce<Record<string, Note[]>>((acc, note) => {
      if (!acc[note.course]) {
        acc[note.course] = [];
      }
      acc[note.course].push(note);
      return acc;
    }, {});
  };

  const foundationNotes = filterNotesByLevel("foundation");
  const diplomaNotes = filterNotesByLevel("diploma");
  const degreeNotes = filterNotesByLevel("degree");

  const foundationCourses = groupNotesByCourse(foundationNotes);
  const diplomaCourses = groupNotesByCourse(diplomaNotes);
  const degreeCourses = groupNotesByCourse(degreeNotes);

  const renderNotesList = (courseNotes: Record<string, Note[]>) => {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Object.entries(courseNotes).map(([course, courseNotesList]) => (
          <Card key={course} className="overflow-hidden">
            <CardHeader className="bg-neutral-50 border-b border-neutral-200 p-5">
              <CardTitle className="font-sans font-medium text-lg text-neutral-800">
                {course}
              </CardTitle>
            </CardHeader>
            <CardContent className="p-5">
              <ul className="space-y-3">
                {courseNotesList.map((note) => (
                  <li key={note.id} className="flex items-start">
                    <CheckCircle className="h-5 w-5 text-[#800000] mt-0.5 mr-2" />
                    <Link href={`/notes/${note.id}`}>
                      <a className="text-[#14397d] hover:text-[#800000] hover:underline">
                        {note.title}
                      </a>
                    </Link>
                  </li>
                ))}
              </ul>
              <div className="mt-5">
                <Link href={`/notes?course=${encodeURIComponent(course)}`}>
                  <a className="text-sm text-[#800000] hover:text-[#690000] font-medium flex items-center">
                    View all resources
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-4 w-4 ml-1"
                      viewBox="0 0 20 20"
                      fill="currentColor"
                    >
                      <path
                        fillRule="evenodd"
                        d="M10.293 5.293a1 1 0 011.414 0l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414-1.414L12.586 11H5a1 1 0 110-2h7.586l-2.293-2.293a1 1 0 010-1.414z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </a>
                </Link>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-64" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Card key={i}>
              <CardHeader>
                <Skeleton className="h-6 w-40" />
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                  <Skeleton className="h-4 w-full" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <Tabs defaultValue="foundation" value={activeTab} onValueChange={setActiveTab}>
      <TabsList className="border-b border-gray-200 w-full justify-start mb-8 bg-transparent">
        <TabsTrigger
          value="foundation"
          className="py-4 px-1 data-[state=active]:border-[#800000] data-[state=active]:text-[#800000] data-[state=active]:border-b-2 rounded-none border-transparent border-b-2"
        >
          Foundation Level
        </TabsTrigger>
        <TabsTrigger
          value="diploma"
          className="py-4 px-1 data-[state=active]:border-[#800000] data-[state=active]:text-[#800000] data-[state=active]:border-b-2 rounded-none border-transparent border-b-2"
        >
          Diploma Level
        </TabsTrigger>
        <TabsTrigger
          value="degree"
          className="py-4 px-1 data-[state=active]:border-[#800000] data-[state=active]:text-[#800000] data-[state=active]:border-b-2 rounded-none border-transparent border-b-2"
        >
          Degree Level
        </TabsTrigger>
      </TabsList>

      <TabsContent value="foundation" className="mt-8">
        {Object.keys(foundationCourses).length > 0 ? (
          renderNotesList(foundationCourses)
        ) : (
          <p className="text-center text-neutral-600">No foundation level notes available.</p>
        )}
      </TabsContent>

      <TabsContent value="diploma" className="mt-8">
        {Object.keys(diplomaCourses).length > 0 ? (
          renderNotesList(diplomaCourses)
        ) : (
          <p className="text-center text-neutral-600">No diploma level notes available.</p>
        )}
      </TabsContent>

      <TabsContent value="degree" className="mt-8">
        {Object.keys(degreeCourses).length > 0 ? (
          renderNotesList(degreeCourses)
        ) : (
          <p className="text-center text-neutral-600">No degree level notes available.</p>
        )}
      </TabsContent>
    </Tabs>
  );
};

export default NoteTabs;
