import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { ChevronLeft } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { CodeNote } from "@shared/schema";
import CodeBlock from "@/components/CodeBlock";

const CodeNoteDetails = () => {
  const { id } = useParams();
  const codeNoteId = parseInt(id);

  const { data: codeNote, isLoading, error } = useQuery<CodeNote>({
    queryKey: [`/api/code-notes/${codeNoteId}`],
    enabled: !isNaN(codeNoteId),
  });

  if (isLoading) {
    return (
      <div className="py-12 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <Link href="/code-notes">
              <Button variant="ghost" className="text-[#14397d] hover:text-[#800000]">
                <ChevronLeft className="mr-2 h-4 w-4" />
                Back to Code Notes
              </Button>
            </Link>
          </div>
          <div className="max-w-4xl mx-auto">
            <Skeleton className="h-10 w-3/4 mb-4" />
            <div className="mb-6">
              <Skeleton className="h-4 w-full mb-2" />
              <Skeleton className="h-4 w-4/5" />
            </div>
            <Skeleton className="h-64 w-full rounded-md" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !codeNote) {
    return (
      <div className="py-12 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <Link href="/code-notes">
              <Button variant="ghost" className="text-[#14397d] hover:text-[#800000]">
                <ChevronLeft className="mr-2 h-4 w-4" />
                Back to Code Notes
              </Button>
            </Link>
          </div>
          <Card className="max-w-4xl mx-auto">
            <CardContent className="p-6">
              <h1 className="text-2xl font-bold text-red-600 mb-4">Error Loading Code Note</h1>
              <p className="text-neutral-600">
                The requested code note could not be found or there was an error loading it. Please try again later.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="py-12 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <Link href="/code-notes">
            <Button variant="ghost" className="text-[#14397d] hover:text-[#800000]">
              <ChevronLeft className="mr-2 h-4 w-4" />
              Back to Code Notes
            </Button>
          </Link>
        </div>
        <article className="max-w-4xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-sans font-bold text-neutral-800 mb-4">
            {codeNote.title}
          </h1>
          <p className="text-lg text-neutral-600 mb-6">{codeNote.description}</p>
          
          <CodeBlock
            title={codeNote.title}
            language={codeNote.language}
            code={codeNote.code}
            tags={codeNote.tags}
          />
        </article>
      </div>
    </div>
  );
};

export default CodeNoteDetails;
