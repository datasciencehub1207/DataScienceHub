import { useQuery } from "@tanstack/react-query";
import Hero from "@/components/Hero";
import ResourceCard from "@/components/ResourceCard";
import NoteTabs from "@/components/NoteTabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Resource } from "@shared/schema";

const Home = () => {
  const { data: resources, isLoading: resourcesLoading } = useQuery<Resource[]>({
    queryKey: ["/api/resources"],
  });

  return (
    <>
      <Hero />

      {/* Resources Quick Links */}
      <div className="py-12 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl md:text-3xl font-sans font-bold text-center text-neutral-800 mb-12">
            Explore Resources
          </h2>
          {resourcesLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
              {[1, 2, 3, 4].map((i) => (
                <div
                  key={i}
                  className="flex flex-col items-center p-6 bg-neutral-50 border border-neutral-200 rounded-lg"
                >
                  <Skeleton className="w-16 h-16 rounded-full mb-4" />
                  <Skeleton className="w-40 h-6 mb-2" />
                  <Skeleton className="w-full h-4" />
                  <Skeleton className="w-4/5 h-4 mt-1" />
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 md:gap-8">
              {resources?.map((resource) => (
                <ResourceCard
                  key={resource.id}
                  title={resource.title}
                  description={resource.description}
                  icon={resource.icon}
                  link={resource.link}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Featured Notes Section */}
      <section id="featured-notes" className="py-12 bg-neutral-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-10">
            <h2 className="text-2xl md:text-3xl font-sans font-bold text-neutral-800 mb-4">
              Course Notes
            </h2>
            <p className="text-lg text-neutral-600">
              Comprehensive study materials organized by foundation, diploma, and degree levels.
            </p>
          </div>

          <NoteTabs />
        </div>
      </section>
    </>
  );
};

export default Home;
