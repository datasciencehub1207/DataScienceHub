import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import GPAForm from "@/components/GPAForm";
import CGPAForm from "@/components/CGPAForm";
import {
  Table,
  TableBody,
  TableCaption,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const GPACalculator = () => {
  const [activeTab, setActiveTab] = useState("gpa");

  return (
    <section id="calculator" className="py-12 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-10">
          <h1 className="text-3xl md:text-4xl font-sans font-bold text-neutral-800 mb-4">
            GPA & CGPA Calculator
          </h1>
          <p className="text-lg text-neutral-600">
            Calculate your academic performance metrics easily with these tools.
          </p>
        </div>

        <Tabs defaultValue="gpa" value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="border-b border-neutral-200 w-full justify-start bg-transparent">
            <TabsTrigger
              value="gpa"
              className="py-4 px-6 data-[state=active]:border-[#800000] data-[state=active]:text-[#800000] data-[state=active]:border-b-2 rounded-none border-transparent border-b-2"
            >
              GPA Calculator
            </TabsTrigger>
            <TabsTrigger
              value="cgpa"
              className="py-4 px-6 data-[state=active]:border-[#800000] data-[state=active]:text-[#800000] data-[state=active]:border-b-2 rounded-none border-transparent border-b-2"
            >
              CGPA Calculator
            </TabsTrigger>
          </TabsList>

          <TabsContent value="gpa" className="mt-6">
            <GPAForm />
          </TabsContent>

          <TabsContent value="cgpa" className="mt-6">
            <CGPAForm />
          </TabsContent>
        </Tabs>

        <div className="bg-white p-6 rounded-lg border border-neutral-200 mt-8">
          <h3 className="text-lg font-medium text-neutral-800 mb-3">Grading System at Data Science Hub</h3>
          <div className="overflow-x-auto">
            <Table>
              <TableCaption>Data Science Hub grading system</TableCaption>
              <TableHeader className="bg-neutral-50">
                <TableRow>
                  <TableHead>Grade</TableHead>
                  <TableHead>Description</TableHead>
                  <TableHead>Grade Points</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">S</TableCell>
                  <TableCell>Outstanding</TableCell>
                  <TableCell>10</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">A</TableCell>
                  <TableCell>Excellent</TableCell>
                  <TableCell>9</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">B</TableCell>
                  <TableCell>Very Good</TableCell>
                  <TableCell>8</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">C</TableCell>
                  <TableCell>Good</TableCell>
                  <TableCell>7</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">D</TableCell>
                  <TableCell>Satisfactory</TableCell>
                  <TableCell>6</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">E</TableCell>
                  <TableCell>Pass</TableCell>
                  <TableCell>5</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">U</TableCell>
                  <TableCell>Fail</TableCell>
                  <TableCell>0</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </div>
        </div>
      </div>
    </section>
  );
};

export default GPACalculator;
