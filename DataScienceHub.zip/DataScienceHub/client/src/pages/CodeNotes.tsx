import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import CodeBlock from "@/components/CodeBlock";
import { CodeNote } from "@shared/schema";

const CodeNotes = () => {
  const { data: codeNotes, isLoading, error } = useQuery<CodeNote[]>({
    queryKey: ["/api/code-notes"],
  });

  return (
    <section id="code" className="py-12 bg-neutral-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-10">
          <h1 className="text-3xl md:text-4xl font-sans font-bold text-neutral-800 mb-4">
            Code Notes
          </h1>
          <p className="text-lg text-neutral-600">
            Useful code snippets and programming examples to help you master concepts.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {isLoading
            ? Array(4)
                .fill(0)
                .map((_, i) => (
                  <div key={i} className="bg-white rounded-lg shadow-md overflow-hidden border border-neutral-200">
                    <div className="p-4 bg-neutral-50 border-b border-neutral-200 flex justify-between items-center">
                      <Skeleton className="h-6 w-40" />
                      <div className="flex space-x-2">
                        <Skeleton className="h-5 w-5" />
                        <Skeleton className="h-5 w-5" />
                      </div>
                    </div>
                    <div className="p-4">
                      <Skeleton className="h-40 w-full rounded-md" />
                      <div className="mt-4">
                        <Skeleton className="h-5 w-40" />
                        <div className="flex flex-wrap gap-2 mt-2">
                          <Skeleton className="h-5 w-20" />
                          <Skeleton className="h-5 w-24" />
                          <Skeleton className="h-5 w-28" />
                        </div>
                      </div>
                    </div>
                  </div>
                ))
            : error ? (
                <div className="col-span-full text-center py-8 text-red-500">
                  Error loading code notes
                </div>
              ) : codeNotes?.length === 0 ? (
                <div className="col-span-full text-center py-8 text-neutral-500">
                  No code notes found
                </div>
              ) : (
                codeNotes?.map((codeNote) => (
                  <Link key={codeNote.id} href={`/code-notes/${codeNote.id}`}>
                    <a className="block h-full">
                      <CodeBlock
                        title={codeNote.title}
                        language={codeNote.language}
                        code={codeNote.code}
                        tags={codeNote.tags}
                      />
                    </a>
                  </Link>
                ))
              )}
        </div>

        <div className="mt-8 text-center">
          <Button className="bg-[#800000] hover:bg-[#690000]">
            View All Code Snippets
          </Button>
        </div>
      </div>
    </section>
  );
};

export default CodeNotes;
