import { useQuery } from "@tanstack/react-query";
import NoteTabs from "@/components/NoteTabs";

const Notes = () => {
  return (
    <section id="notes" className="py-12 bg-neutral-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-10">
          <h1 className="text-3xl md:text-4xl font-sans font-bold text-neutral-800 mb-4">
            Course Notes
          </h1>
          <p className="text-lg text-neutral-600">
            Comprehensive study materials organized by foundation, diploma, and degree levels.
          </p>
        </div>

        <NoteTabs />
      </div>
    </section>
  );
};

export default Notes;
