import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { FileDown, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { PYQ } from "@shared/schema";

const PreviousYearQuestions = () => {
  const [level, setLevel] = useState<string>("all");
  const [subject, setSubject] = useState<string>("all");
  const [year, setYear] = useState<string>("all");

  // Get all PYQs
  const {
    data: pyqs,
    isLoading,
    error,
  } = useQuery<PYQ[]>({
    queryKey: [`/api/pyqs`, level, subject, year],
  });

  // Get all unique subjects
  const subjects = Array.from(new Set(pyqs?.map((pyq) => pyq.subject) || []));
  // Get all unique years
  const years = Array.from(new Set(pyqs?.map((pyq) => pyq.year) || [])).sort((a, b) => b - a);

  const getBadgeColorByExamType = (examType: string) => {
    switch (examType.toLowerCase()) {
      case "end term":
        return "bg-green-100 text-green-800";
      case "mid term":
        return "bg-yellow-100 text-yellow-800";
      case "quiz":
        return "bg-blue-100 text-blue-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <section id="pyqs" className="py-12 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-10">
          <h1 className="text-3xl md:text-4xl font-sans font-bold text-neutral-800 mb-4">
            Previous Year Questions
          </h1>
          <p className="text-lg text-neutral-600">
            Practice with past exam papers to prepare effectively for upcoming assessments.
          </p>
        </div>

        {/* Filter controls */}
        <div className="mb-8">
          <div className="flex flex-wrap gap-4">
            <div>
              <label htmlFor="level" className="block text-sm font-medium text-neutral-700 mb-1">
                Level
              </label>
              <Select
                value={level}
                onValueChange={(value) => setLevel(value)}
              >
                <SelectTrigger id="level" className="w-[180px]">
                  <SelectValue placeholder="Select Level" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Levels</SelectItem>
                  <SelectItem value="foundation">Foundation</SelectItem>
                  <SelectItem value="diploma">Diploma</SelectItem>
                  <SelectItem value="degree">Degree</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label htmlFor="subject" className="block text-sm font-medium text-neutral-700 mb-1">
                Subject
              </label>
              <Select
                value={subject}
                onValueChange={(value) => setSubject(value)}
              >
                <SelectTrigger id="subject" className="w-[240px]">
                  <SelectValue placeholder="Select Subject" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Subjects</SelectItem>
                  {subjects.map((subj) => (
                    <SelectItem key={subj} value={subj}>
                      {subj}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label htmlFor="year" className="block text-sm font-medium text-neutral-700 mb-1">
                Year
              </label>
              <Select
                value={year}
                onValueChange={(value) => setYear(value)}
              >
                <SelectTrigger id="year" className="w-[180px]">
                  <SelectValue placeholder="Select Year" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Years</SelectItem>
                  {years.map((yr) => (
                    <SelectItem key={yr} value={yr.toString()}>
                      {yr}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </div>

        {/* PYQ Table */}
        <div className="overflow-x-auto bg-white rounded-lg shadow">
          <Table>
            <TableHeader className="bg-neutral-50">
              <TableRow>
                <TableHead className="w-[30%]">Subject</TableHead>
                <TableHead>Level</TableHead>
                <TableHead>Year</TableHead>
                <TableHead>Term</TableHead>
                <TableHead>Type</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {isLoading ? (
                Array(5)
                  .fill(0)
                  .map((_, index) => (
                    <TableRow key={index}>
                      <TableCell>
                        <Skeleton className="h-5 w-40" />
                      </TableCell>
                      <TableCell>
                        <Skeleton className="h-5 w-20" />
                      </TableCell>
                      <TableCell>
                        <Skeleton className="h-5 w-10" />
                      </TableCell>
                      <TableCell>
                        <Skeleton className="h-5 w-20" />
                      </TableCell>
                      <TableCell>
                        <Skeleton className="h-5 w-16" />
                      </TableCell>
                      <TableCell>
                        <div className="flex justify-end gap-2">
                          <Skeleton className="h-9 w-16" />
                          <Skeleton className="h-9 w-24" />
                        </div>
                      </TableCell>
                    </TableRow>
                  ))
              ) : error ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-red-500">
                    Error loading previous year questions
                  </TableCell>
                </TableRow>
              ) : pyqs?.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-center py-8 text-neutral-500">
                    No previous year questions found
                  </TableCell>
                </TableRow>
              ) : (
                pyqs?.map((pyq) => (
                  <TableRow key={pyq.id}>
                    <TableCell className="font-medium">{pyq.subject}</TableCell>
                    <TableCell>
                      {pyq.level.charAt(0).toUpperCase() + pyq.level.slice(1)}
                    </TableCell>
                    <TableCell>{pyq.year}</TableCell>
                    <TableCell>{pyq.term}</TableCell>
                    <TableCell>
                      <Badge
                        className={`${getBadgeColorByExamType(pyq.examType)} font-semibold`}
                        variant="outline"
                      >
                        {pyq.examType}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-[#800000] border-[#800000]"
                        >
                          <Eye className="h-4 w-4 mr-1" />
                          View
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="text-[#14397d] border-[#14397d]"
                          onClick={() => window.open(pyq.fileUrl, "_blank")}
                        >
                          <FileDown className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        </div>

        <div className="mt-6 flex justify-between items-center">
          <div className="text-sm text-neutral-600">
            Showing {pyqs?.length || 0} results
          </div>
          <div className="flex space-x-2">
            <Button
              variant="outline"
              size="sm"
              className="text-neutral-600"
              disabled={true}
            >
              Previous
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="text-neutral-600"
              disabled={true}
            >
              Next
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default PreviousYearQuestions;
