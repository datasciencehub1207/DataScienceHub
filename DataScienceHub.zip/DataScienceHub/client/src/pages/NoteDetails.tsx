import { useQuery } from "@tanstack/react-query";
import { useParams } from "wouter";
import { ChevronLeft } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Note } from "@shared/schema";

const NoteDetails = () => {
  const { id } = useParams();
  const noteId = parseInt(id);

  const { data: note, isLoading, error } = useQuery<Note>({
    queryKey: [`/api/notes/${noteId}`],
    enabled: !isNaN(noteId),
  });

  if (isLoading) {
    return (
      <div className="py-12 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <Link href="/notes">
              <Button variant="ghost" className="text-[#14397d] hover:text-[#800000]">
                <ChevronLeft className="mr-2 h-4 w-4" />
                Back to Notes
              </Button>
            </Link>
          </div>
          <div className="max-w-4xl mx-auto">
            <Skeleton className="h-10 w-3/4 mb-4" />
            <div className="flex gap-2 mb-6">
              <Skeleton className="h-6 w-24" />
              <Skeleton className="h-6 w-32" />
            </div>
            <Skeleton className="h-64 w-full rounded-md" />
          </div>
        </div>
      </div>
    );
  }

  if (error || !note) {
    return (
      <div className="py-12 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-6">
            <Link href="/notes">
              <Button variant="ghost" className="text-[#14397d] hover:text-[#800000]">
                <ChevronLeft className="mr-2 h-4 w-4" />
                Back to Notes
              </Button>
            </Link>
          </div>
          <Card className="max-w-4xl mx-auto">
            <CardContent className="p-6">
              <h1 className="text-2xl font-bold text-red-600 mb-4">Error Loading Note</h1>
              <p className="text-neutral-600">
                The requested note could not be found or there was an error loading it. Please try again later.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  // Function to convert markdown content to HTML (simplified version)
  // In a real app, you might use a full markdown parser like marked.js
  const renderMarkdown = (content: string) => {
    // Replace headings
    let html = content
      .replace(/^# (.*$)/gm, '<h1 class="text-3xl font-bold my-4">$1</h1>')
      .replace(/^## (.*$)/gm, '<h2 class="text-2xl font-bold my-3">$1</h2>')
      .replace(/^### (.*$)/gm, '<h3 class="text-xl font-bold my-2">$1</h3>')
      // Replace paragraphs
      .replace(/^(?!<h[1-6]|<ul|<ol|<li|<blockquote|<pre|<code)(.+$)/gm, '<p class="my-2">$1</p>');
    
    return { __html: html };
  };

  return (
    <div className="py-12 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-6">
          <Link href="/notes">
            <Button variant="ghost" className="text-[#14397d] hover:text-[#800000]">
              <ChevronLeft className="mr-2 h-4 w-4" />
              Back to Notes
            </Button>
          </Link>
        </div>
        <article className="max-w-4xl mx-auto">
          <h1 className="text-3xl md:text-4xl font-sans font-bold text-neutral-800 mb-4">
            {note.title}
          </h1>
          <div className="flex flex-wrap gap-2 mb-6">
            <Badge variant="outline" className="text-[#14397d] border-[#14397d]">
              {note.level.charAt(0).toUpperCase() + note.level.slice(1)} Level
            </Badge>
            <Badge variant="outline" className="text-[#800000] border-[#800000]">
              {note.course}
            </Badge>
            <Badge variant="outline" className="text-[#d99f0d] border-[#d99f0d]">
              {note.topic}
            </Badge>
          </div>
          <Card>
            <CardContent className="p-6">
              <div className="prose max-w-none" dangerouslySetInnerHTML={renderMarkdown(note.content)} />
            </CardContent>
          </Card>
        </article>
      </div>
    </div>
  );
};

export default NoteDetails;
