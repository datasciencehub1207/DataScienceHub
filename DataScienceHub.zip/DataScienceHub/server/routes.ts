import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import {
  insertNoteSchema,
  insertPYQSchema,
  insertCodeNoteSchema,
  insertResourceSchema,
  courseGradeSchema,
  semesterSchema
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes
  const apiRouter = "/api";

  // Get all notes
  app.get(`${apiRouter}/notes`, async (req, res) => {
    try {
      const level = req.query.level as string | undefined;
      let notes;
      
      if (level && ['foundation', 'diploma', 'degree'].includes(level)) {
        notes = await storage.getNotesByLevel(level);
      } else {
        notes = await storage.getAllNotes();
      }
      
      res.json(notes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch notes" });
    }
  });

  // Get a single note by ID
  app.get(`${apiRouter}/notes/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const note = await storage.getNoteById(id);
      
      if (!note) {
        return res.status(404).json({ message: "Note not found" });
      }
      
      res.json(note);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch note" });
    }
  });

  // Create a new note
  app.post(`${apiRouter}/notes`, async (req, res) => {
    try {
      const validatedData = insertNoteSchema.parse(req.body);
      const note = await storage.createNote(validatedData);
      res.status(201).json(note);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid note data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create note" });
    }
  });

  // Get all PYQs with optional filtering
  app.get(`${apiRouter}/pyqs`, async (req, res) => {
    try {
      const level = req.query.level as string | undefined;
      const subject = req.query.subject as string | undefined;
      const year = req.query.year ? parseInt(req.query.year as string) : undefined;
      
      const pyqs = await storage.getPYQsByFilter(level, subject, year);
      res.json(pyqs);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch PYQs" });
    }
  });

  // Get a single PYQ by ID
  app.get(`${apiRouter}/pyqs/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const pyq = await storage.getPYQById(id);
      
      if (!pyq) {
        return res.status(404).json({ message: "PYQ not found" });
      }
      
      res.json(pyq);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch PYQ" });
    }
  });

  // Create a new PYQ
  app.post(`${apiRouter}/pyqs`, async (req, res) => {
    try {
      const validatedData = insertPYQSchema.parse(req.body);
      const pyq = await storage.createPYQ(validatedData);
      res.status(201).json(pyq);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid PYQ data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create PYQ" });
    }
  });

  // Get all code notes
  app.get(`${apiRouter}/code-notes`, async (req, res) => {
    try {
      const codeNotes = await storage.getAllCodeNotes();
      res.json(codeNotes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch code notes" });
    }
  });

  // Get a single code note by ID
  app.get(`${apiRouter}/code-notes/:id`, async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const codeNote = await storage.getCodeNoteById(id);
      
      if (!codeNote) {
        return res.status(404).json({ message: "Code note not found" });
      }
      
      res.json(codeNote);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch code note" });
    }
  });

  // Create a new code note
  app.post(`${apiRouter}/code-notes`, async (req, res) => {
    try {
      const validatedData = insertCodeNoteSchema.parse(req.body);
      const codeNote = await storage.createCodeNote(validatedData);
      res.status(201).json(codeNote);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid code note data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create code note" });
    }
  });

  // Get all resources
  app.get(`${apiRouter}/resources`, async (req, res) => {
    try {
      const resources = await storage.getAllResources();
      res.json(resources);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch resources" });
    }
  });

  // Calculate GPA
  app.post(`${apiRouter}/calculate-gpa`, async (req, res) => {
    try {
      const { courses } = req.body;
      
      // Validate each course
      const validatedCourses = z.array(courseGradeSchema).parse(courses);
      
      let totalCredits = 0;
      let totalGradePoints = 0;
      
      validatedCourses.forEach(course => {
        if (course.grade && course.credits) {
          totalCredits += course.credits;
          totalGradePoints += parseFloat(course.grade) * course.credits;
        }
      });
      
      const gpa = totalCredits > 0 ? (totalGradePoints / totalCredits).toFixed(2) : '0.00';
      
      res.json({ gpa, totalCredits });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid course data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to calculate GPA" });
    }
  });

  // Calculate CGPA
  app.post(`${apiRouter}/calculate-cgpa`, async (req, res) => {
    try {
      const { semesters } = req.body;
      
      // Validate each semester
      const validatedSemesters = z.array(semesterSchema).parse(semesters);
      
      let totalCredits = 0;
      let totalGradePoints = 0;
      
      validatedSemesters.forEach(semester => {
        if (semester.gpa !== undefined && semester.credits) {
          totalCredits += semester.credits;
          totalGradePoints += semester.gpa * semester.credits;
        }
      });
      
      const cgpa = totalCredits > 0 ? (totalGradePoints / totalCredits).toFixed(2) : '0.00';
      
      res.json({ cgpa, totalCredits });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid semester data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to calculate CGPA" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
