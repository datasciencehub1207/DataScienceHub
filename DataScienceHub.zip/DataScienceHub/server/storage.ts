import { 
  users, type User, type InsertUser,
  notes, type Note, type InsertNote,
  pyqs, type PYQ, type InsertPYQ,
  codeNotes, type CodeNote, type InsertCodeNote,
  resources, type Resource, type InsertResource
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Notes operations
  getAllNotes(): Promise<Note[]>;
  getNotesByLevel(level: string): Promise<Note[]>;
  getNoteById(id: number): Promise<Note | undefined>;
  createNote(note: InsertNote): Promise<Note>;
  
  // PYQs operations
  getAllPYQs(): Promise<PYQ[]>;
  getPYQsByFilter(level?: string, subject?: string, year?: number): Promise<PYQ[]>;
  getPYQById(id: number): Promise<PYQ | undefined>;
  createPYQ(pyq: InsertPYQ): Promise<PYQ>;
  
  // Code Notes operations
  getAllCodeNotes(): Promise<CodeNote[]>;
  getCodeNoteById(id: number): Promise<CodeNote | undefined>;
  createCodeNote(codeNote: InsertCodeNote): Promise<CodeNote>;
  
  // Resources operations
  getAllResources(): Promise<Resource[]>;
  getResourceById(id: number): Promise<Resource | undefined>;
  createResource(resource: InsertResource): Promise<Resource>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private notes: Map<number, Note>;
  private pyqs: Map<number, PYQ>;
  private codeNotes: Map<number, CodeNote>;
  private resources: Map<number, Resource>;
  
  private userId: number;
  private noteId: number;
  private pyqId: number;
  private codeNoteId: number;
  private resourceId: number;

  constructor() {
    this.users = new Map();
    this.notes = new Map();
    this.pyqs = new Map();
    this.codeNotes = new Map();
    this.resources = new Map();
    
    this.userId = 1;
    this.noteId = 1;
    this.pyqId = 1;
    this.codeNoteId = 1;
    this.resourceId = 1;
    
    // Initialize with sample data
    this.initializeData();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Notes operations
  async getAllNotes(): Promise<Note[]> {
    return Array.from(this.notes.values());
  }
  
  async getNotesByLevel(level: string): Promise<Note[]> {
    return Array.from(this.notes.values()).filter(note => note.level === level);
  }
  
  async getNoteById(id: number): Promise<Note | undefined> {
    return this.notes.get(id);
  }
  
  async createNote(insertNote: InsertNote): Promise<Note> {
    const id = this.noteId++;
    const now = new Date();
    const note: Note = { ...insertNote, id, createdAt: now };
    this.notes.set(id, note);
    return note;
  }
  
  // PYQs operations
  async getAllPYQs(): Promise<PYQ[]> {
    return Array.from(this.pyqs.values());
  }
  
  async getPYQsByFilter(level?: string, subject?: string, year?: number): Promise<PYQ[]> {
    return Array.from(this.pyqs.values()).filter(pyq => {
      if (level && pyq.level !== level && level !== 'all') return false;
      if (subject && pyq.subject !== subject && subject !== 'all') return false;
      if (year && pyq.year !== year && year !== -1) return false;
      return true;
    });
  }
  
  async getPYQById(id: number): Promise<PYQ | undefined> {
    return this.pyqs.get(id);
  }
  
  async createPYQ(insertPYQ: InsertPYQ): Promise<PYQ> {
    const id = this.pyqId++;
    const now = new Date();
    const pyq: PYQ = { ...insertPYQ, id, createdAt: now };
    this.pyqs.set(id, pyq);
    return pyq;
  }
  
  // Code Notes operations
  async getAllCodeNotes(): Promise<CodeNote[]> {
    return Array.from(this.codeNotes.values());
  }
  
  async getCodeNoteById(id: number): Promise<CodeNote | undefined> {
    return this.codeNotes.get(id);
  }
  
  async createCodeNote(insertCodeNote: InsertCodeNote): Promise<CodeNote> {
    const id = this.codeNoteId++;
    const now = new Date();
    const codeNote: CodeNote = { ...insertCodeNote, id, createdAt: now };
    this.codeNotes.set(id, codeNote);
    return codeNote;
  }
  
  // Resources operations
  async getAllResources(): Promise<Resource[]> {
    return Array.from(this.resources.values());
  }
  
  async getResourceById(id: number): Promise<Resource | undefined> {
    return this.resources.get(id);
  }
  
  async createResource(insertResource: InsertResource): Promise<Resource> {
    const id = this.resourceId++;
    const now = new Date();
    const resource: Resource = { ...insertResource, id, createdAt: now };
    this.resources.set(id, resource);
    return resource;
  }
  
  // Initialize with sample data
  private initializeData() {
    // Create sample notes
    const sampleNotes: InsertNote[] = [
      {
        title: "Linear Algebra Notes",
        description: "Comprehensive notes on linear algebra fundamentals",
        content: "# Linear Algebra Fundamentals\n\n## Vectors and Vector Spaces\n\nA vector space is a collection of objects called vectors, which may be added together and multiplied by scalars...",
        level: "foundation",
        course: "Mathematics for Data Science I",
        topic: "Linear Algebra"
      },
      {
        title: "Calculus Fundamentals",
        description: "Key concepts in calculus for data science",
        content: "# Calculus Fundamentals\n\n## Limits and Continuity\n\nThe concept of limit is fundamental to calculus...",
        level: "foundation",
        course: "Mathematics for Data Science I",
        topic: "Calculus"
      },
      {
        title: "Matrix Operations",
        description: "Essential matrix operations for linear algebra",
        content: "# Matrix Operations\n\n## Matrix Addition\n\nGiven two matrices A and B of the same dimensions...",
        level: "foundation",
        course: "Mathematics for Data Science I",
        topic: "Linear Algebra"
      },
      {
        title: "Python for Beginners",
        description: "Introduction to Python programming",
        content: "# Python Basics\n\n## Variables and Data Types\n\nPython is a dynamically typed language...",
        level: "foundation",
        course: "Programming Basics",
        topic: "Python"
      },
      {
        title: "Data Structures in Python",
        description: "Common data structures in Python",
        content: "# Python Data Structures\n\n## Lists\n\nLists are ordered collections of items...",
        level: "foundation",
        course: "Programming Basics",
        topic: "Data Structures"
      },
      {
        title: "Basic Algorithms",
        description: "Introduction to common algorithms",
        content: "# Basic Algorithms\n\n## Searching Algorithms\n\n### Linear Search\n\nLinear search is the most basic search algorithm...",
        level: "foundation",
        course: "Programming Basics",
        topic: "Algorithms"
      },
      {
        title: "Probability Theory",
        description: "Fundamentals of probability theory",
        content: "# Probability Theory\n\n## Basic Probability Concepts\n\nProbability is a measure of the likelihood that an event will occur...",
        level: "foundation",
        course: "Statistics for Data Science",
        topic: "Probability"
      },
      {
        title: "Statistical Distributions",
        description: "Common probability distributions",
        content: "# Statistical Distributions\n\n## Normal Distribution\n\nThe normal distribution is a continuous probability distribution...",
        level: "foundation",
        course: "Statistics for Data Science",
        topic: "Distributions"
      },
      {
        title: "Hypothesis Testing",
        description: "Introduction to hypothesis testing",
        content: "# Hypothesis Testing\n\n## Null and Alternative Hypotheses\n\nHypothesis testing is a method of statistical inference...",
        level: "foundation",
        course: "Statistics for Data Science",
        topic: "Hypothesis Testing"
      },
      {
        title: "Supervised Learning",
        description: "Introduction to supervised learning algorithms",
        content: "# Supervised Learning\n\n## Classification vs Regression\n\nSupervised learning algorithms are trained using labeled examples...",
        level: "diploma",
        course: "Machine Learning Techniques",
        topic: "Supervised Learning"
      },
      {
        title: "Unsupervised Learning",
        description: "Introduction to unsupervised learning techniques",
        content: "# Unsupervised Learning\n\n## Clustering Algorithms\n\nUnsupervised learning involves training algorithms on data without labeled responses...",
        level: "diploma",
        course: "Machine Learning Techniques",
        topic: "Unsupervised Learning"
      },
      {
        title: "Model Evaluation",
        description: "Techniques for evaluating machine learning models",
        content: "# Model Evaluation\n\n## Metrics for Classification\n\nAccuracy, precision, recall, F1-score, and ROC AUC are common metrics...",
        level: "diploma",
        course: "Machine Learning Techniques",
        topic: "Model Evaluation"
      },
      {
        title: "SQL Fundamentals",
        description: "Basic SQL for data management",
        content: "# SQL Fundamentals\n\n## Basic Queries\n\nSQL (Structured Query Language) is used to communicate with relational databases...",
        level: "diploma",
        course: "Database Management",
        topic: "SQL"
      },
      {
        title: "Database Design",
        description: "Principles of database design",
        content: "# Database Design\n\n## Normalization\n\nDatabase normalization is the process of structuring a database...",
        level: "diploma",
        course: "Database Management",
        topic: "Database Design"
      },
      {
        title: "Neural Networks",
        description: "Introduction to neural networks",
        content: "# Neural Networks\n\n## Perceptrons and Activation Functions\n\nA neural network is a series of algorithms that endeavors to recognize underlying relationships in a set of data...",
        level: "degree",
        course: "Deep Learning Specialization",
        topic: "Neural Networks"
      },
      {
        title: "CNN Architectures",
        description: "Convolutional Neural Network architectures",
        content: "# CNN Architectures\n\n## LeNet, AlexNet, VGG, GoogLeNet, ResNet\n\nConvolutional Neural Networks (CNNs) are a class of deep neural networks...",
        level: "degree",
        course: "Deep Learning Specialization",
        topic: "CNNs"
      },
      {
        title: "RNNs and LSTMs",
        description: "Recurrent Neural Networks and Long Short-Term Memory",
        content: "# RNNs and LSTMs\n\n## Recurrent Neural Networks\n\nRNNs are a class of neural networks that allow previous outputs to be used as inputs...",
        level: "degree",
        course: "Deep Learning Specialization",
        topic: "RNNs"
      }
    ];
    
    sampleNotes.forEach(note => {
      this.createNote(note);
    });
    
    // Create sample PYQs
    const samplePYQs: InsertPYQ[] = [
      {
        subject: "Mathematics for Data Science I",
        level: "foundation",
        year: 2023,
        term: "Jan-May",
        examType: "End Term",
        fileUrl: "/api/download/pyq/math_2023_endterm.pdf"
      },
      {
        subject: "Programming Basics",
        level: "foundation",
        year: 2023,
        term: "Jan-May",
        examType: "Mid Term",
        fileUrl: "/api/download/pyq/programming_2023_midterm.pdf"
      },
      {
        subject: "Statistics for Data Science",
        level: "foundation",
        year: 2022,
        term: "Aug-Dec",
        examType: "End Term",
        fileUrl: "/api/download/pyq/stats_2022_endterm.pdf"
      },
      {
        subject: "Machine Learning Techniques",
        level: "diploma",
        year: 2022,
        term: "Jan-May",
        examType: "Quiz",
        fileUrl: "/api/download/pyq/ml_2022_quiz.pdf"
      },
      {
        subject: "Database Management",
        level: "diploma",
        year: 2021,
        term: "Aug-Dec",
        examType: "End Term",
        fileUrl: "/api/download/pyq/db_2021_endterm.pdf"
      },
      {
        subject: "Deep Learning Specialization",
        level: "degree",
        year: 2021,
        term: "Jan-May",
        examType: "Mid Term",
        fileUrl: "/api/download/pyq/dl_2021_midterm.pdf"
      }
    ];
    
    samplePYQs.forEach(pyq => {
      this.createPYQ(pyq);
    });
    
    // Create sample code notes
    const sampleCodeNotes: InsertCodeNote[] = [
      {
        title: "Python NumPy Basics",
        description: "Essential NumPy operations for numerical computing",
        code: "# NumPy array creation and operations\nimport numpy as np\n\n# Create arrays\narr1 = np.array([1, 2, 3, 4, 5])\narr2 = np.array([6, 7, 8, 9, 10])\n\n# Basic operations\nprint(arr1 + arr2)  # Addition\nprint(arr1 * arr2)  # Element-wise multiplication\nprint(np.dot(arr1, arr2))  # Dot product\n\n# Array reshaping\nmatrix = np.array([[1, 2, 3], [4, 5, 6]])\nprint(matrix.reshape(3, 2))\n\n# Statistical functions\nprint(np.mean(arr1))\nprint(np.std(arr2))\nprint(np.max(matrix))",
        language: "python",
        tags: ["NumPy", "Arrays", "Matrix Operations"]
      },
      {
        title: "Pandas DataFrame Operations",
        description: "Essential operations for data manipulation with Pandas",
        code: "# Pandas DataFrame operations\nimport pandas as pd\n\n# Create a simple DataFrame\ndata = {\n    'Name': ['John', 'Anna', 'Peter', 'Linda'],\n    'Age': [28, 24, 35, 32],\n    'City': ['New York', 'Paris', 'Berlin', 'London'],\n    'Score': [89, 95, 82, 88]\n}\n\ndf = pd.DataFrame(data)\nprint(df.head())\n\n# Basic operations\nprint(df.describe())  # Statistical summary\nprint(df['Age'].mean())  # Mean of Age column\n\n# Filtering data\nyoung_people = df[df['Age'] < 30]\nprint(young_people)\n\nhigh_scorers = df[df['Score'] > 85]\nprint(high_scorers)\n\n# Grouping and aggregation\ngrouped = df.groupby('City').mean()\nprint(grouped)",
        language: "python",
        tags: ["Pandas", "DataFrame", "Data Analysis"]
      },
      {
        title: "Matplotlib Visualization",
        description: "Creating visualizations with Matplotlib",
        code: "# Matplotlib visualization examples\nimport matplotlib.pyplot as plt\nimport numpy as np\n\n# Sample data\nx = np.linspace(0, 10, 100)\ny1 = np.sin(x)\ny2 = np.cos(x)\n\n# Create a simple line plot\nplt.figure(figsize=(10, 6))\nplt.plot(x, y1, label='sin(x)', color='blue')\nplt.plot(x, y2, label='cos(x)', color='red')\nplt.title('Sine and Cosine Functions')\nplt.xlabel('x')\nplt.ylabel('y')\nplt.legend()\nplt.grid(True)\nplt.show()\n\n# Create a scatter plot\nplt.figure(figsize=(10, 6))\nplt.scatter(x[::5], y1[::5], c='blue', label='sin(x)')\nplt.scatter(x[::5], y2[::5], c='red', label='cos(x)')\nplt.title('Scatter Plot of Sine and Cosine')\nplt.xlabel('x')\nplt.ylabel('y')\nplt.legend()\nplt.grid(True)\nplt.show()",
        language: "python",
        tags: ["Matplotlib", "Visualization", "Plotting"]
      },
      {
        title: "Scikit-learn Linear Regression",
        description: "Implementing linear regression with scikit-learn",
        code: "# Linear Regression with scikit-learn\nimport numpy as np\nimport matplotlib.pyplot as plt\nfrom sklearn.linear_model import LinearRegression\nfrom sklearn.model_selection import train_test_split\nfrom sklearn.metrics import mean_squared_error, r2_score\n\n# Generate sample data\nnp.random.seed(42)\nX = 2 * np.random.rand(100, 1)\ny = 4 + 3 * X + np.random.randn(100, 1)\n\n# Split the data\nX_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)\n\n# Train the model\nmodel = LinearRegression()\nmodel.fit(X_train, y_train)\n\n# Make predictions\ny_pred = model.predict(X_test)\n\n# Evaluate the model\nmse = mean_squared_error(y_test, y_pred)\nr2 = r2_score(y_test, y_pred)\nprint(f'Coefficient: {model.coef_[0][0]:.4f}')\nprint(f'Intercept: {model.intercept_[0]:.4f}')\nprint(f'Mean Squared Error: {mse:.4f}')\nprint(f'R² Score: {r2:.4f}')\n\n# Plot the results\nplt.figure(figsize=(10, 6))\nplt.scatter(X_test, y_test, color='blue', label='Actual data')\nplt.plot(X_test, y_pred, color='red', linewidth=2, label='Prediction')\nplt.title('Linear Regression')\nplt.xlabel('X')\nplt.ylabel('y')\nplt.legend()\nplt.show()",
        language: "python",
        tags: ["scikit-learn", "Linear Regression", "Machine Learning"]
      }
    ];
    
    sampleCodeNotes.forEach(codeNote => {
      this.createCodeNote(codeNote);
    });
    
    // Create sample resources
    const sampleResources: InsertResource[] = [
      {
        title: "Course Notes",
        description: "Comprehensive study materials organized by subjects and topics",
        icon: "FileText",
        link: "/notes"
      },
      {
        title: "Previous Year Questions",
        description: "Practice with past exam papers to prepare effectively",
        icon: "HelpCircle",
        link: "/pyqs"
      },
      {
        title: "Code Notes",
        description: "Useful code snippets and programming examples",
        icon: "Code",
        link: "/code-notes"
      },
      {
        title: "GPA Calculator",
        description: "Calculate your GPA and CGPA with our easy-to-use calculator",
        icon: "Calculator",
        link: "/gpa-calculator"
      }
    ];
    
    sampleResources.forEach(resource => {
      this.createResource(resource);
    });
  }
}

export const storage = new MemStorage();
